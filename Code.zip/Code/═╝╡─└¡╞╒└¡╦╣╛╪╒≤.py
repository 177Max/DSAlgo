n,m=map(int,input().split())
l=[[int(i-i) for i in range(n)] for i in range(n)]
for _ in range(m):
    a,b=map(int,input().split())
    l[a][b]=-1
    l[b][a]=-1
for i in range(n):
    t=l[i]
    x=sum(t)
    l[i][i]=-x
for _ in l:
    k=map(lambda x:str(x),_)
    print(" ".join(k))