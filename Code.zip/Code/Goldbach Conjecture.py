def primejudge(num):
    if num <= 1:
        return False
    
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
            
    return True

x=int(input())
i=3
if x%2!=0:
    print("2 "+str(x-2))
else:
    t=x//3+1
    while i <=t:
        if primejudge(i) is True and primejudge(x-i) is True:
            print(str(i)+" "+str(x-i))
            break
        else:
            i+=2
##写了一个质数判断函数，比较方便，当然能这么写其实是因为题目确定了给的数能写成两个质数的和，毕竟哥德巴赫猜想还没有被证明（）