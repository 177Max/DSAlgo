L=list(input())
x=0
i=len(L)-1
j=0

while j<=i:
    if L[j]=="h":
        x+=1
        j+=1
        break
    j+=1

while j<=i:
    if L[j]=="e":
        x+=1
        j+=1
        break
    j+=1

while j<=i:
    if L[j]=="l":
        x+=1
        j+=1
        break
    j+=1

while j<=i:
    if L[j]=="l":
        x+=1
        j+=1
        break
    j+=1

while j<=i:
    if L[j]=="o":
        x+=1
        j+=1
        break
    j+=1



if x==5:
    print("YES")
else:
    print("NO")


##这题遍历一遍就好，最开始语法忘了pop和del函数怎么用卡了半天，后面瞎用又卡了半天，最后想着没必要删掉已经判断的字母，遂AC