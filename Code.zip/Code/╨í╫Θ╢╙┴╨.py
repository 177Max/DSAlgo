from collections import deque

t=int(input())
groups={}
member_to_group={}
for _ in range(t):
    members=list(map(int,input().split()))
    group_id=members[0]
    groups[group_id]=deque()
    for member in members:
        member_to_group[member]=group_id

queue=deque()

queue_set=set()


while True:
    command=input().split()
    if command[0]=='STOP':
        break
    elif command[0]=='ENQUEUE':
        x=int(command[1])
        group=member_to_group.get(x, None)
        if group is None:
            group=x
            groups[group]=deque([x])
            member_to_group[x]=group
        else:
            groups[group].append(x)
        if group not in queue_set:
            queue.append(group)
            queue_set.add(group)
    elif command[0]=='DEQUEUE':
        if queue:
            group=queue[0]
            x=groups[group].popleft()
            print(x)
            if not groups[group]:
                queue.popleft()
                queue_set.remove(group)