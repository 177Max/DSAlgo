n=int(input())
L=[int(i) for i in input().split()]
T={}
ans=""
sum=0
for i in range(n):
    if L[i] not in T.keys():
        T[L[i]]=[i+1]
    else:
        T[L[i]]+=[i+1]
L.sort()
for i in range(n):
    sum+=L[i]*(n-i-1)
L=list(set(L))
L.sort()
for t in L:
    for x in T[t]:
        ans+=str(x)+" "
average=sum/n
print(ans[:-1])
print('%.2f' % average)