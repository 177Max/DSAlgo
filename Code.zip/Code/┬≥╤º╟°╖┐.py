n=int(input())
ans=[1]*n
L=[i[1:-1] for i in input().split()]
D=[sum(map(int,i.split(','))) for i in L]
Price=[int(i) for i in input().split()]
Pricee=Price[0:]
Pricee.sort()
Value=[D[i]/Price[i] for i in range(n)]
Valuee=Value[0:]
Valuee.sort()
if n%2==1:
    middle1=Valuee[int(n/2)]
    middle2=Pricee[int(n/2)]
else:
    middle1=(Valuee[int(n/2)]+Valuee[int(n/2-1)])/2
    middle2=(Pricee[int(n/2)]+Pricee[int(n/2-1)])/2

for i in range(n):
    if Value[i]<=middle1 or Price[i]>=middle2:
        ans[i]=0
num=ans.count(1)
if num==-1:
    num=0
print(num)