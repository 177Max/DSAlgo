L=['a','e','i','o','u','A','E','I','O','U','y','Y']
l=list(input())
k=[]
for x in l:
    if x not in L:
        k.append(x.lower())
finalstring=''
for x in k:
    finalstring+="."+x
print(finalstring)
##没注意到y也是元音错了一次...但我怎么记得y真的不算元音