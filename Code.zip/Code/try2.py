n = int(input())
a = list(map(int,input().split()))
stack = []
for i in range(n):
    while stack and a[stack[-1]]<a[i]: # 注意pop前要检查栈是否非空
        a[stack.pop()] = i+1 # 原地修改，较为简洁
    stack.append(i) # stack存元素下标而非元素本身
for x in stack:
    a[x] = 0
print(*a)