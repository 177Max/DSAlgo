class Node:
    def __init__(self):
        self.value=None
        self.left=None
        self.right=None

def build_fbi_tree(string):
    root=Node()
    if "0" not in string:
        root.value="I"
    elif "1" not in string:
        root.value="B"
    else:
        root.value="F"
    
    x=len(string)//2
    if x>0:
        root.left=build_fbi_tree(string[:x])
        root.right=build_fbi_tree(string[x:])
    return root

def post_traverse(node):
    ans=[]
    if node:
        ans.extend(post_traverse(node.left))
        ans.extend(post_traverse(node.right))
        ans.append(node.value)
    return "".join(ans)
n=input()
string=input()
root=build_fbi_tree(string)
print(post_traverse(root))