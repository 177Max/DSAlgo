def merge_sort(array):
    if len(array)>1:
        middle=len(array)//2
        Left=array[:middle]
        Right=array[middle:]

        merge_sort(Left)
        merge_sort(Right)

        i=j=k=0
        while i<len(Left) and j<len(Right):
            if Left[i]<=Right[j]:
                array[k]=Left[i]
                i+=1
            else:
                array[k]=Right[j]
                j+=1
            k+=1
        

        while i<len(Left):
            array[k]=Left[i]
            i+=1
            k+=1
        while j<len(Right):
            array[k]=Right[j]
            j+=1
            k+=1
    return array

m,k=map(int,input().split())
L=[int(i) for i in input().split()]
merge_sort(L)
if k==m:
    print(L[-1])
elif k==0:
    if L[0]>1:
        print("1")
    else:
        print("-1")
else:
    if L[k-1]==L[k]:
        print("-1")
    else:
        print(L[k-1])
##注意边界条件