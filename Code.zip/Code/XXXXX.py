t=int(input())
ans=[]
for k in range(t):
    n,x=map(int,input().split())
    L=list(map(int,input().split()))
    m=-1
    s=sum(L)
    if s%x!=0:
        ans.append(n)
    else:
        for i in range(n):
            s-=L[i]
            if s%x!=0:
                m=max(i+1,n-i-1,m)##如果一边不整除，那么另一边也不整除
        ans.append(m)
for t in ans:
    print(t)
##这题卡了很久很久，因为每次都想着便利一点用sum函数就可以了，枚举出每个子序列然后取模，但是这样其实浪费了大量算力，tle得人都快疯了
##这题就属于是典型的思路谁都会，但是不深入思考肯定过不了的，在群里看到老师发的其他同学的证明对我启发很大，谢谢老师和同学！
  