L=[str(i) for i in input().split()]
L.reverse()
print(" ".join(L))
##一脸懵逼地ac了