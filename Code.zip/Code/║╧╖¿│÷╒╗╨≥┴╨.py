class Stack:
    def __init__(self):
        self.items=[]
    def is_empty(self):
        return self.items==[]
    def push(self,item):
        self.items.append(item)
    def pop(self):
        return self.items.pop()
    def peek(self):
        return self.items[len(self.items)-1]
    def size(self):
        return len(self.items)

def test_output_sequence(string,output):
    manipulate_Stack=Stack()
    origin=list(string)
    if len(string)!=len(output):
        return "NO"
    for x in output:
        while (manipulate_Stack.is_empty() or manipulate_Stack.peek()!=x) and origin:
            manipulate_Stack.push(origin.pop(0))
        
        if manipulate_Stack.is_empty() or manipulate_Stack.peek()!=x:
            return "NO"
        
        manipulate_Stack.pop()
    
    return "YES"
string=input().strip()
while True:
    try:
        output=input().strip()
        print(test_output_sequence(string,output))

    except EOFError:
        break