n=int(input())
q=[]
for _ in range(n):
    x,y=map(int,input().split())
    l=[["0" for i in range(y+2)]]
    for _ in range(x):
        e=["0"]+list(input())+["0"]
        l.append(e)
    l.append(["0" for i in range(y+2)])
    r=[[0 for i in range(y+2)] for i in range(x+2)]
    ans=0
    for i in range(1,x+1):
        for j in range(1,y+1):
            if l[i][j]=="W":
                k=[str(i)+" "+str(j)]
                g=[str(i)+" "+str(j)]
            else:
                k=[]
                g=[]
            while len(g)>0:
                a,b=map(int,g[0].split())
                if l[a][b]=="." or r[a][b]!=0:
                    g=[]
                    continue
                if "W"==l[a][b+1] and str(a)+" "+str(b+1) not in k:
                    k.append(str(a)+" "+str(b+1))
                    g.append(str(a)+" "+str(b+1))
                if "W"==l[a+1][b] and str(a+1)+" "+str(b) not in k:
                    k.append(str(a+1)+" "+str(b))
                    g.append(str(a+1)+" "+str(b))
                if "W"==l[a][b-1] and str(a)+" "+str(b-1) not in k:
                    k.append(str(a)+" "+str(b-1))
                    g.append(str(a)+" "+str(b-1))
                if "W"==l[a-1][b] and str(a-1)+" "+str(b) not in k:
                    k.append(str(a-1)+" "+str(b))
                    g.append(str(a-1)+" "+str(b))
                if "W"==l[a+1][b+1] and str(a+1)+" "+str(b+1) not in k:
                    k.append(str(a+1)+" "+str(b+1))
                    g.append(str(a+1)+" "+str(b+1))
                if "W"==l[a-1][b+1] and str(a-1)+" "+str(b+1) not in k:
                    k.append(str(a-1)+" "+str(b+1))
                    g.append(str(a-1)+" "+str(b+1))
                if "W"==l[a+1][b-1] and str(a+1)+" "+str(b-1) not in k:
                    k.append(str(a+1)+" "+str(b-1))
                    g.append(str(a+1)+" "+str(b-1))
                if "W"==l[a-1][b-1] and str(a-1)+" "+str(b-1) not in k:
                    k.append(str(a-1)+" "+str(b-1))
                    g.append(str(a-1)+" "+str(b-1))
                g.pop(0)
                r[a][b]=1

            if len(k)>ans:
                ans=len(k)
    q.append(ans)
for y in q:
    print(y)