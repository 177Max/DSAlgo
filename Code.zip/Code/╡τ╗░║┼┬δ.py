class TrieNode:
    def __init__(self):
        self.child={}
        
class Trie:
    def __init__(self):
        self.root=TrieNode()

    def insert(self,nums):
        current=self.root
        for x in nums:
            if x not in current.child:
                current.child[x]=TrieNode()
            current=current.child[x]
            
    def search(self,num):
        current=self.root
        for x in num:
            if x not in current.child:
                return 0
            current=current.child[x]
        return 1
    
for _ in range(int(input())):
    nums=[]
    for _ in range(int(input())):
        nums.append(str(input()))
    nums.sort(reverse=True)
    s=0
    trie=Trie()
    for num in nums:
        s+=trie.search(num)
        trie.insert(num)
    if s>0:
        print('NO')
    else:
        print('YES')
