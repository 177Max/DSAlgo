n=int(input())
i=1
ans=[]
while i<=n:
    L=[int(j) for j in input().split()]
    j=1
    skill={}
    hurt={}

    while j<=L[0]:
        z=[int(k) for k in input().split()]
        if z[0] in skill.keys():
            skill[z[0]]+=[z[1]]
        else:
            skill[z[0]]=[z[1]]
        j+=1
    r=list(skill.keys())
    r.sort()
    for x in r:
        a=skill[x]
        a.sort(reverse=True)
        if len(a)<=L[1]:
            hurt[x]=sum(a)
        else:
            hurt[x]=sum(a[:L[1]])
    total=0
    for x in r:
        total+=hurt[x]
        if total>=L[2]:
            ans.append(str(x))
            break
    if total<L[2]:
        ans.append("alive")
    i+=1
for t in ans:
    print(t)
##伤害最大化打满一套，如果在途中死了就跳出记录时间，活着就alive
##需要注意的是打满一套有诸多限制，比如每秒出手次数，是否同一时间，以及各自出手的伤害，比较好的方法用把时间和伤害（列表存储）搞成字典，然后判断

        