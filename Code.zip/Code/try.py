#很久没有利用vscode来敲代码了，同样地也很久没有利用python编写程序，无论是做题还是真正地应用，记得之前计算概论写的代码都只能用来解决某一道具体的问题而难以有固定的模板来解决一类难题，这是非常不好的，通常这样的代码又长又丑，时间长了自己回去看都会看不明白，现在回来学数算，希望能有所进步，此文件特地设立用以代码尝试
q=int(input())
w=[]
def union(L,x,y):
    if L[x-1][0]!=L[y-1][0]:
        L[x-1],L[y-1]=L[y-1]+L[x-1],L[y-1]+L[x-1]
for _ in range(q):
    n,m=map(int,input().split())
    L=[[i+1] for i in range(n)]
    for i in range(m):
        x,y=map(int,input().split())
        union(L,x,y)
    ans=str(" ".join(str(t[0]) for t in L))
    w.append(ans)
for t in w:
    print(t)
