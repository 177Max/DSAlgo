class Stack:
    def __init__(self):
        self.items=[]
    def is_empty(self):
        return self.items==[]
    def push(self,item):
        self.items.append(item)
    def pop(self):
        return self.items.pop()
    def peek(self):
        return self.items[len(self.items)-1]
    def size(self):
        return len(self.items)

def base_converse(decimal_number,base):
    digits="0123456789ABCDEF"
    remainder_stack=Stack()
    while decimal_number>0:
        remainder=decimal_number%base
        remainder_stack.push(remainder)
        decimal_number=decimal_number//base
    
    new_number=""
    while not remainder_stack.is_empty():
        new_number=new_number+digits[remainder_stack.pop()]
    return new_number
print(base_converse(25,2))
