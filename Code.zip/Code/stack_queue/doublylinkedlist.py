class Node:
    def __init__(self,value):
        self.value=value
        self.prev=None
        self.next=None

class DoublyLinkedList:
    def __init__(self):
        self.head=None
        self.tail=None

    def insert_before(self,node,new_node):
        if node is None:
            self.head=new_node
            self.tail=new_node
        else:
            new_node.next=node
            new_node.prev=node.prev
            if node.prev is not None:
                node.prev=new_node
            else:
                self.head=new_node
            node.prev=new_node
    
    def display_forward(self):
        current=self.head
        while current is not None:
            print(current.value,end=" ")
            current=current.next
        print()

    def display_backward(self):
        current=self.tail
        while current is not None:
            print(current.value,end=" ")
            current=current.prev
        print()