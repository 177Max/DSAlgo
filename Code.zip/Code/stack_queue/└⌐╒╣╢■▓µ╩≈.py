def build_tree(preorder):
    if not preorder or preorder[0]=='.':
        return None,preorder[1:]
    root=preorder[0]
    left,preorder=build_tree(preorder[1:])
    right,preorder=build_tree(preorder)
    return (root,left,right),preorder

def inorder(tree):
    if tree is None:
        return ''
    root,left,right=tree
    return inorder(left)+root+inorder(right)

def postorder(tree):
    if tree is None:
        return ''
    root,left,right=tree
    return postorder(left)+postorder(right)+root

preorder=input().strip()

tree,_=build_tree(preorder)

print(inorder(tree))
print(postorder(tree))