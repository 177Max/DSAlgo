import heapq
from collections import defaultdict

out=defaultdict(int)
pigs_heap=[]
pigs_stack=[]

while True:
    try:
        s=input()
    except EOFError:
        break

    if s=="pop":
        if pigs_stack:
            out[pigs_stack.pop()]+=1
    elif s=="min":
        if pigs_stack:
            while True:
                x=heapq.heappop(pigs_heap)
                if not out[x]:
                    heapq.heappush(pigs_heap,x)
                    print(x)
                    break
                out[x]-=1
    else:
        y=int(s.split()[1])
        pigs_stack.append(y)
        heapq.heappush(pigs_heap,y)