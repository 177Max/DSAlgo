class Stack:
    def __init__(self):
        self.items=[]
    def is_empty(self):
        return self.items==[]
    def push(self,item):
        self.items.append(item)
    def pop(self):
        return self.items.pop()
    def peek(self):
        return self.items[len(self.items)-1]
    def size(self):
        return len(self.items)

def parenthesis_check(string):
    s=Stack()
    balanced=True
    index=0
    while index<len(string) and balanced is True:
        symbol=string[index]
        if symbol=="(":
            s.push("(")
        else:
            if s.is_empty() is True:
                balanced=False
            else:
                s.pop()
        index+=1
    
    if balanced is True and s.is_empty() is True:
        return True
    else:
        return False
print(parenthesis_check())