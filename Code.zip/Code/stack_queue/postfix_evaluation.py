class Stack:
    def __init__(self):
        self.items=[]
    def is_empty(self):
        return self.items==[]
    def peek(self):
        return self.items[len(self.items)-1]
    def pop(self):
        return self.items.pop()
    def push(self,item):
        self.items.append(item)
    def size(self):
        return len(self.items)
def postfixEval(postfixExpression):
    operandStack=Stack()
    tokenList=postfixExpression.split()
    for token in tokenList:
        if token not in "+-*/":
            operandStack.push(float(token))
        else:
            operand2=operandStack.pop()
            operand1=operandStack.pop()
            result=doMath(token,operand1,operand2)
            operandStack.push(result)
    return operandStack.pop()

def doMath(operator,operand1,operand2):
    if operator=="*":
        return operand1*operand2
    elif operator=="/":
        return operand1/operand2
    elif operator=="+":
        return operand1+operand2
    else:
        return operand1-operand2

n=int(input())
for _ in range(n):
    expression=input()
    print(f"{postfixEval(expression):.2f}")