class Stack:
    def __init__(self):
        self.items=[]
    def is_empty(self):
        return self.items==[]
    def push(self,item):
        self.items.append(item)
    def pop(self):
        return self.items.pop()
    def peek(self):
        return self.items[len(self.items)-1]
    def size(self):
        return len(self.items)

def infixToPostfix(infixexpression):
    precedence={}
    precedence["*"]=3
    precedence["/"]=3
    precedence["+"]=2
    precedence["-"]=2
    precedence["("]=1
    operatorStack=Stack()
    postfixList=[]
    tokenList=list(infixexpression)

    for token in tokenList:
        if token in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" or token in "0123456789":
            postfixList.append(token)
        elif token=="(":
            operatorStack.push(token)
        elif token==")":
            topToken=operatorStack.pop()
            while topToken!="(":
                postfixList.append(topToken)
                topToken=operatorStack.pop()
        else:
            while not operatorStack.is_empty() and precedence[operatorStack.peek()]>=precedence[token]:
                postfixList.append(operatorStack.pop())
            operatorStack.push(token)
    
    while not operatorStack.is_empty():
        postfixList.append(operatorStack.pop())
    return " ".join(postfixList)

print(infixToPostfix("(A+B*C)*D"))