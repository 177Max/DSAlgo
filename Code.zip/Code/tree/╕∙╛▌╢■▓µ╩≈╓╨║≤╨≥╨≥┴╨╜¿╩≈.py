def build_tree(inorder,postorder):
    if not inorder or not postorder:
        return []
    
    root_val=postorder[-1]
    root_index=inorder.index(root_val)

    left_inorder=inorder[:root_index]
    right_inorder=inorder[root_index+1:]

    left_postorder=postorder[:len(left_inorder)]
    right_postorder=postorder[len(left_inorder):-1]

    root=[root_val]
    root.extend(build_tree(left_inorder,left_postorder))
    root.extend(build_tree(right_inorder,right_postorder))

    return root
def main():
    inorder=input().strip()
    postorder=input().strip()
    preorder=build_tree(inorder,postorder)
    print("".join(preorder))

if __name__=="__main__":
    main()