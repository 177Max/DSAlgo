class TreeNode:
    def __init__(self,value):
        self.value=value
        self.left=None
        self.right=None

def build_tree(preorder,inorder):
    if not preorder or not inorder:
        return None
    root_value=preorder[0]
    root=TreeNode(root_value)
    root_index_inorder=inorder.index(root_value)
    root.left=build_tree(preorder[1:1+root_index_inorder],inorder[:root_index_inorder])
    root.right=build_tree(preorder[1+root_index_inorder:],inorder[root_index_inorder+1:])
    return root
def postorder_traversal(root):
    if root is None:
        return ""
    return postorder_traversal(root.left)+postorder_traversal(root.right)+root.value
while True:
    try:
        preorder=input().strip()
        inorder=input().strip()
        root=build_tree(preorder,inorder)
        print(postorder_traversal(root))
    except EOFError:
        break
