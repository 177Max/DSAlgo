import heapq

class Node:
    def __init__(self,weight,char=None):
        self.weight=weight
        self.char=char
        self.left=None
        self.right=None

    def __lt__(self,other):
        if self.weight==other.weight:
            return self.char<other.char
        return self.weight<other.weight

def build_huffman_tree(characters):
    heap=[]
    for char,weight in characters.items():
        heapq.heappush(heap,Node(weight,char))

    while len(heap)>1:
        left=heapq.heappop(heap)
        right=heapq.heappop(heap)
        merged=Node(left.weight+right.weight,min(left.char,right.char))
        merged.left=left
        merged.right=right
        heapq.heappush(heap,merged)
    
    return heap[0]

def encode_huffman_tree(root):
    codes={}

    def traverse(node,code):
        if node.left is None and node.left is None:
            codes[node.char]=code
        else:
            traverse(node.left,code+"0")
            traverse(node.right,code+"1")
    
    traverse(root,"")
    return codes

def huffman_encoding(codes,string):
    encoded=""
    for char in string:
        encoded+=codes[char]
    return encoded

def huffman_decoding(root,encoded_string):
    decoded=""
    node=root
    for bit in encoded_string:
        if bit=="0":
            node=node.left

        else:
            node=node.right

        if node.left is None and node.right is None:
            decoded+=node.char
            node=root
    
    return decoded

n=int(input())
characters={}
for _ in range(n):
    char,weight=input().split()
    characters[char]=int(weight)

huffman_tree=build_huffman_tree(characters)
codes=encode_huffman_tree(huffman_tree)
strings=[]
while True:
    try:
        line=input()
        strings.append(line)
    except EOFError:
        break

results=[]
for string in strings:
    if string[0] in ("0","1"):
        results.append(huffman_decoding(huffman_tree,string))
    else:
        results.append(huffman_decoding(codes,string))
for t in results:
    print(t)
