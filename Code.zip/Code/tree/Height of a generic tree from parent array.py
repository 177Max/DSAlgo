class TreeNode:
    def __init__(self):
        self.left=None
        self.right=None

def tree_height(node):
    if node is None:
        return -1
    return max(tree_height(node.left),tree_height(node.right))+1

def count_leaves(node):
    if node is None:
        return 0
    if node.left is None and node.right is None:
        return 1
    return count_leaves(node.left)+count_leaves(node.right)##不用+1，算的是子节点，用不着根结点