class TreeNode:
    def __init__(self,value):
        self.value=value
        self.left=None
        self.right=None

def build_tree(postfix):
    stack=[]
    for char in postfix:
        node=TreeNode(char)
        if char.isupper():
            node.right=stack.pop()
            node.left=stack.pop()
        stack.append(node)
    return stack[0]
def level_order_traversal(root):
    queue=[root]
    traversal=[]
    while queue:
        node=queue.pop(0)
        traversal.append(node.value)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return traversal
n=int(input().strip())
for i in range(n):
    postfix=input().strip()
    root=build_tree(postfix)
    queue_expression=level_order_traversal(root)[::-1]
    print("".join(queue_expression))