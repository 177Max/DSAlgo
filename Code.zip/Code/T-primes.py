import math
def primejudge(num):
    if num<=1:
        return False
    if num==2:
        return True
    if num!=2 and num%2==0:
        return False
    for i in range(3, int(num**0.5) + 1,2):
        if num % i == 0:
            return False       
    return True
 
n=int(input())
NUM=[int(i) for i in input().split()]
k=[]
for t in NUM:
    x=math.sqrt(t)
    x=math.floor(x)
    if x**2==t:
        k.append(x)
    else:
        k.append(1)
for t in k:
    if t==1 or primejudge(t) is False:
        print("NO")
        continue
    else:
        print("YES")
##没能用python测试ac用了pypy，依稀记得这题第一次做的时候就做了很久，前前后后提交了四十多次才ac，这次也优化了比较多次，交上去之后重新去了解了一下筛法，现在会一点了
##本题我依然用了这个方法，在2050那题中就改用筛法了






