L=input().split("+")

max=0
for x in L:
    a=x.find("n")
    x1=x[:a]
    if x1=="":
        x1=1
    else:
        x1=int(x1)
    x2=int(x[a+2:])
    if x1!=0 and x2>=max:
        max=x2

print("n^"+str(max))
##一开始把debug时用的测试输出也给print了，错了一次。本题找n即可，根据n定位前后关键信息，n前面是1的情况比较坑，判断一下即可









