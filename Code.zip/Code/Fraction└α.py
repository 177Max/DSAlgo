def gcd(m,n):
    while m&n!=0:
        x=m%n
        m=n
        n=x
    return n

class Fraction:
    def __init__(self,top,bottom):
        self.num=top
        self.den=bottom
    
    def __str__(self):
        return(str(self.num)+"/"+str(self.den))
    
    def __add__(self,otherfraction):
        newnum=self.num*otherfraction.den+self.den*otherfraction.num
        newden=self.den*otherfraction.den
        common=gcd(self.den,otherfraction.den)
        return(Fraction(newnum//common,newden//common))

L=[int(i) for i in input().split()]
print(Fraction(L[0],L[1])+Fraction(L[2],L[3]))
##我感觉我还是不太清楚类想做什么，大概理解了一下，一个类可以看作一个集合，里面对特定的元素进行考虑，类中有一系列方法，在涉及类中对象的操作时会调用这些方法，目前我只能理解到这里
##这题没有什么难度，用欧几里得算法就能轻松解决