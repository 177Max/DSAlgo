q=[]
m,n=map(int,input().split())
L=[int(i) for i in input().split()]
ans=0
for i in L:
    if i not in q:
        if len(q)==m:
            q.pop()
            q.insert(0,i)
            ans+=1
        else:
            q.insert(0,i)
            ans+=1

print(ans)