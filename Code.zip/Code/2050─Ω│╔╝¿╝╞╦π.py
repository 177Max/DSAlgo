from math import sqrt
N=10010
s=[True]*N
p=2
while p*p<=N:
	if s[p] is True:
		for i in range(p*2,N,p):
			s[i]=False
	p+=1
s[0]=False
s[1]=False
m,n=map(int,input().split())
for i in range(m):
	L=list(map(int,input().split()))
	sum=0
	for num in L:
		x=int(sqrt(num))
		if s[x] is True and num==x*x:
			sum+=num
	average=sum/len(L)
	if sum==0:
		print(0)
	else:
		print('%.2f' % average)
##终于能用代码实现筛法了