def dfs(node,graph,result):
    if node not in graph:
        result.append(node)
        return
    children=graph[node]
    temp=[node]+children
    temp.sort()
    for child in temp:
        if child==node:
            result.append(node)
        elif child in graph:
            dfs(child,graph,result)

def main():
    n=int(input())
    graph={}
    all_nodes=set()
    child_nodes=set()

    for _ in range(n):
        line=list(map(int, input().split()))
        node=line[0]
        all_nodes.add(node)
        if len(line)>1:
            children=line[1:]
            graph[node]=children
            child_nodes.update(children)
        else:
            graph[node]=[]

    top_level_nodes=list(all_nodes-child_nodes)
    top_level_nodes.sort()

    result=[]
    for node in top_level_nodes:
        dfs(node,graph,result)

    for node in result:
        print(node)

if __name__ == "__main__":
    main()