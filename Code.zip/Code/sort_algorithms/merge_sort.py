def merge_sort(array):
    if len(array)>1:
        middle=len(array)//2##从中间分成两段
        Left=array[:middle]
        Right=array[middle:]

        merge_sort(Left)##merge_sort函数的作用就是排序好
        merge_sort(Right)

        i=j=k=0##接下来是插入，把Left和Right的值互插
        while i<len(Left) and j<len(Right):
            if Left[i]<=Right[j]:
                array[k]=Left[i]
                i+=1
            else:
                array[k]=Right[j]
                j+=1
            k+=1
        

        while i<len(Left):##这步是检查还有没有元素被落下
            array[k]=Left[i]
            i+=1
            k+=1
        while j<len(Right):
            array[k]=Right[j]
            j+=1
            k+=1
    return array


L=[12,11,13,5,6,7,7,7,7,7,7]
merge_sort(L)
print(L)