def shell_sort(array,n):
    gap=n//2

    while gap>0:
        j=gap

        while j<n:
            i=j-gap

            while i>=0:
                if array[i+gap]>array[i]:
                    break
                else:
                    array[i+gap],array[i]=array[i],array[i+gap]

                i-=gap
            j+=1
        gap=gap//2

    return array


L=[12,34,54,2,3]
shell_sort(L,len(L))
print(L)