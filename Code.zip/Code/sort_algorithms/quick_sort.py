##双指针实现
def quick_sort(array,left,right):
    if left<right:##这个保证了递归的限制
        partition_position=partition(array,left,right)##随便找指针的位置，注意此时相当于排好了i，并且array已经修改，考虑i前后即可
        quick_sort(array,left,partition_position-1)##这两个是递归，继续考虑i前和i后的array
        quick_sort(array,partition_position+1,right)
    return array
def partition(array,left,right):
    i=left
    j=right-1
    pivot=array[right]##直接取末尾的数字为指针，目标是找出所有比他小的数字和比他大的数字
    while i<=j:
        while i<=right and array[i]<pivot:
            i+=1##这一步保证了i的递增，所有的数字都比指针小，但是最后的array[i]会大于等于指针
        while j>=left and array[j]>=pivot:
            j-=1##这一步保证了j的递减，所有的数字都比指针大，但是最后的array[j]会小于指针
        if i<j:##在还没有遍历完pivot前的所有数字时会出现这种情况
            array[i],array[j]=array[j],array[i]##交换array[i]和array[j]，保证循环能够继续进行
    ##跳出循环时，必然有i=j+1，此时这个i时不满足array[i]比pivot小的，但是array[j]此时满足比pivot小，此时i和j形成了一个分界线
    if array[i]>pivot:##这个判断考虑的其实是边界条件，比如已经排好的，就不用交换了，但是没排好的一般情况，这个交换保证了i前面的数字都小于array[i],i后面的数字都大于array[i]
        array[i],array[right]=array[right],array[i]
    return i




##单指针实现
def partition(array,low,high):
    pivot=array[high]
    i=low-1##这个i其实可以理解为比pivot小的数字的编号
    for j in range(low,high):##遍历列表，找出所有比pivot小的数字
        if array[j]<=pivot:
            i+=1
            array[i],array[j]=array[j],array[i]##这步交换，i位置上原来是什么不重要，重要的是换完之后是比pivot小的数字
    array[i+1],array[high]=array[high],array[i+1]##最终i+1位置上的数一定就不小于pivot了，交换即可
    return i+1

def quick_sort(array,low,high):
    if low<high:
        position=partition(array,low,high)
        quick_sort(array,low,position-1)
        quick_sort(array,position+1,high)
    return array





L=[7,6,3,10,4,9,8]
quick_sort(L,0,len(L)-1)
print(L)