def partition(array,low,high):
    pivot=array[high]
    i=low-1
    for j in range(low,high):
        if array[j]<=pivot:
            i+=1
            array[i],array[j]=array[j],array[i]
    array[i+1],array[high]=array[high],array[i+1]
    return i+1

def quick_sort(array,low,high):
    if low<high:
        position=partition(array,low,high)
        quick_sort(array,low,position-1)
        quick_sort(array,position+1,high)
    return array





L=[7,6,3,10,4,9,8]
quick_sort(L,0,len(L)-1)
print(L)