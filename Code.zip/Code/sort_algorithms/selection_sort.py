def selection_sort(array):
    n=len(array)
    for i in range(n):
        minimal=i
        for j in range(i+1,n):##对于给定的i，遍历其后的数值找到最小值并交换，相当于每次前进一步并且把最小的放在最前面
            if array[minimal]>array[j]:
                minimal=j
        array[i],array[minimal]=array[minimal],array[i]##和冒泡排序比起来每排好一个只需要进行一次交换
    return array
L=[64,25,12,22,11]
selection_sort(L)
print(L)