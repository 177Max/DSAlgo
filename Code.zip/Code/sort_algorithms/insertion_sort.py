def insertion_sort(array):
    for i in range(1,len(array)):
        j=i
        while array[j-1]>array[j] and j>0:##这步我自己写可能就漏掉了，对反向遍历的限制
            array[j-1],array[j]=array[j],array[j-1]##这步交换
            j-=1##指标前移，进一步判断移到前面去的东西是否比更前面的还小
    return array
arr=[64,34,25,12,22,11,90]
insertion_sort(arr)
print(arr)