def bubble_sort(array):
    n=len(array)
    for i in range(n):
        swapped=False
        for j in range(0,n-i-1):##这里之所以取成n-i-1是因为一个i的操作效果相当于把最大数放到array的最后端
            if array[j]>array[j+1]:
                array[j],array[j+1]=array[j+1],array[j]
                swapped=True##修改交换标志
        if swapped==False:##只有完成排序才会保留False
            break
    return array


L=[64,34,25,12,22,11,90]
bubble_sort(L)
print(L)