L=[int(i) for i in input().split()]
l=set(L)
k=[]

max=L.count(L[0])
for x in l:

    num=L.count(x)

    if num==max:
        k.append(x)
    elif num>max:
        max=num
        k=[x]
k.sort()
ans=""
for i in k:
    ans+=str(i)+" "
print(ans[:-1])
##最开始的尝试忘记更改max的值了，思路都比较直接，做完之后感觉python的语法回来一点了，没忘太干净
