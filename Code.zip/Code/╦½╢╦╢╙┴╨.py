n=int(input())
ans=[]
for i in range(n):
    m=int(input())
    L=[]
    for j in range(m):
        w=[int(i) for i in input().split()]
        x=w[0]
        y=w[1]
        if x==1:
            L.append(str(y))
        if x==2:
            if len(L)==0:
                ans.append("NULL")
                break
            elif y==0:
                L.pop(0)
            elif y==1:
                L.pop()
    t=" ".join(L)
    if t=="":
        ans.append("NULL")
    else:
        ans.append(t)
for t in ans:
    print(t)
##一开始想用deque实现来着，除去一个addFront就可以了，但是后来想想还是再直接写一次，不同方法都要练习