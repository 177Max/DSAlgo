n,m=input().split()
n=int(n)
m=int(m)
present={}
k=[]
i=1
j=0
while i<=n:
    w=[int(j) for j in input().split()]
    x=w[0]/w[1]
    k.append([x,w[1]])
    i+=1
k.sort(reverse=True)
kilo=0
value=0
while kilo<=m and j<=n-1:
    if kilo+k[j][1]<=m:
        value+=k[j][0]*k[j][1]
        kilo+=k[j][1]
    else:
        value+=(m-kilo)*k[j][0]
        break
    j+=1
print(round(value,1))
##这题思路比较清晰，比第一次做好多了，第一次做死活没反应过来可以相同的平均价值，错用字典，注意到之后就比较简单了


