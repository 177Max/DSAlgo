l=[]

while True:
    ans=""
    n,p,m=map(int,input().split())
    x=n
    if n==0 and p==0 and m==0:
        break
    else:
        L=[int(i) for i in range(1,n+1)]
        for i in range(x):
            p=(p+m-1)%n

            x=L.pop(p-1)
            if p==0:
                p=1##这里要考虑一下如果报到最后一个人，要重新开始，把指标切换成1
            n-=1
            ans+=str(x)+","
    l.append(ans[:-1])
for x in l:
    print(x)
##这题一开始边输入边输出错了好几次，看到老师发在群里的代码才知道要一起输出...