def moveOneStep(numDisk:int,initiation:str,destination:str):
    print("{}:{}->{}".format(numDisk,initiation,destination))

def move(numDisks:int,initiation:str,temptation:str,destination:str):
    if numDisks==1:
        moveOneStep(1,initiation,destination)
    else:
        move(numDisks-1,initiation,destination,temptation)
        moveOneStep(numDisks,initiation,destination)
        move(numDisks-1,temptation,initiation,destination)
n,a,b,c=input().split()
move(int(n),a,b,c)
##这题的思路提示里讲的非常清楚,就是反复迭代，主要操作有二，一是将n-1个盘子移到temptation上，然后把最底下的盘子（编号n）移到destination上，此时他们的出发点都是initiation
##第二步相当于把n-1个盘子从temptation移动到destination，当然要借助initiation，如此递归即可。具体的代码实现参考了一下老师发的题解，我自己写的时候函数的temptation没定义好，出错了几次