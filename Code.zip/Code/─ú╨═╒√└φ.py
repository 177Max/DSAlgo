n=int(input())
kind={}
key=[]
ans=[]
for i in range(n):
    model,argu=map(str,input().split("-"))
    key.append(model)
    if model in kind.keys():
        kind[model]+=[argu]
    else:
        kind[model]=[argu]
key=list(set(key))
key.sort()

for t in key:
    s=t+": "
    num={}
    m=[]
    for x in kind[t]:
        rank=x[-1]
        if rank=="M":
            numb=float(x[:-1])*1000000
        if rank=="B":
            numb=float(x[:-1])*1000000000
        m.append(numb)
        num[numb]=x
    m.sort()
    for t in m:
        s+=num[t]+", "
    ans.append(s)
for t in ans:
    print(t[:-2])

